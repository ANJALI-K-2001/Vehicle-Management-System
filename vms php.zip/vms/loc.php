<?php
 
$con = new mysqli('localhost','root','');
$db = mysqli_select_db($con,'vms');

 # Fetching data using POST method...
 $id = $_POST["user_id"];
 $latitude = $_POST["latitude"];
 $longitude = $_POST["longitude"];

    $q = "UPDATE users SET latitude='$latitude', longitude='$longitude' WHERE user_id='$id' ";
    $result = mysqli_query($con, $q);

    if ($result) {
        $response['status'] = "1";
        $response['message'] = "Location updated successfully";
    }
    else {
        $response['status'] = "0";
        $response['message'] = "Updation failed..Please try again!";
    }

    echo json_encode($response);
?>