<?php

    $con = new mysqli("localhost", "root","");
    $db = mysqli_select_db($con, "vms");

        $regno = $_POST['reg_no'];
        $username=$_POST['userid'];
        $originalImgName= $_FILES['filename']['name'];
        $tempName= $_FILES['filename']['tmp_name'];
        $folder="uploads/";

        if(move_uploaded_file($tempName,$folder.$originalImgName)){
                $query = "UPDATE addvehicle SET insurance_certificate = '$originalImgName' WHERE  userid='$username' && reg_no='$regno'" ;

                if(mysqli_query($con,$query)){
                
                	$response['status'] = "1";
                  $response['message'] = "File uploaded successfully";
                }
                else {
                	$response['status'] = "0";
                  $response['message'] = "Data insertion failed";
                }
              }
                else {
        	$response['status'] = "0";
          $response['message'] = "File moving failed";
                }
    
        echo json_encode($response);
    
?>