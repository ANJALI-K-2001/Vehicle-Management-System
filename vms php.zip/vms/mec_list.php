<?php
include('Config.php');
 // $lat = "10.7761138";
    // $lng = "76.0313939";

    $lat = $_POST['lat'];
    $lng = $_POST['lng'];


    $sql = "SELECT mechanic_id,username,password,fullname,phone_no,email,place,mechanic_type,(
      6371 * acos (
      cos ( radians('$lat') )
      * cos( radians( latitude ) )
      * cos( radians( longitude ) - radians('$lng') )
      + sin ( radians('$lat') )
      * sin( radians( latitude ) )
        )
    ) AS distance
    FROM mechanic
    HAVING distance <10
    ORDER BY distance
    LIMIT 0 , 20;";

                $result = mysqli_query($con, $sql) or die("Error in query: ".mysqli_error($con));
    
                if (mysqli_num_rows($result) >0) {
                
                  while($row[] =mysqli_fetch_array($result,MYSQLI_ASSOC)) {
                      $tem = $row;
                      $j['status'] = "1";
                      $j['data'] = $tem;
                  }
                } else {
                    $j['status'] = "0";
                    $j['data'] = "";
                }
                
                //echo json_encode($j);
                 echo json_encode($j);
                
            

?>