<?php
include('Config.php');

$feedbackid = $_POST["feedbackid"];
$name = $_POST["name"];
$messages = $_POST["message"];

$q = "INSERT INTO appfeedback(feedbackid,name,message) VALUES ('$feedbackid', '$name','$messages')";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['message'] = "Feedback send Successfully";
}
else {
    $response['status'] = "0";
    $response['message'] = " Failed to send Feedback " ;
}

echo json_encode($response);

?>