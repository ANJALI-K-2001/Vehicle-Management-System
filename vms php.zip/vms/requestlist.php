<?php

$con = new mysqli('localhost','root','');
$db = mysqli_select_db($con,'vms');



$q = $con -> prepare("SELECT id,status,user_id,username,fullname,phone_no FROM requestmec WHERE status='request'");
$q -> execute();
$q -> bind_result($id, $status, $user_id, $username,$Fullname,$phone_no);

$users = array();

while( $q -> fetch() ) {
    $temp = array();

    $temp['id'] = $id;
    $temp['status'] = $status;
    $temp['user_id'] = $user_id;
    $temp['username'] = $username;
    $temp['fullname'] = $Fullname;
    $temp['phone_no'] = $phone_no;
    
    
    

    array_push($users, $temp);
}

echo json_encode($users);

?>