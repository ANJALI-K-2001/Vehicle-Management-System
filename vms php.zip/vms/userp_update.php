<?php

$con = new mysqli('localhost','root','');
$db = mysqli_select_db($con,'vms');


$id = $_POST["user_id"];
$user = $_POST["username"];
$name = $_POST["fullname"];
$phone = $_POST["phone_no"];
$email = $_POST["email"];
$address = $_POST["address"];
$license = $_POST["license_no"];
$gender = $_POST["gender"];



$q = "UPDATE users SET username='$user', fullname='$name', phone_no='$phone', email='$email', address='$address', license_no='$license', gender='$gender' WHERE user_id='$id' ";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['error'] = "Profile Updation Successful";
}
else {
    $response['status'] = "0";
    $response['error'] = "Profile Updation Failed" ;
}

echo json_encode($response);

?>