<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vms');
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  die();
}

$mech_id =$_POST['mech_id'];

$stmt = $conn->prepare("SELECT name,message FROM feedback WHERE mech_id='$mech_id'");
$stmt->execute();
$stmt->bind_result($name,$message);
$products = array();
while($stmt->fetch())
{
  $temp = array();
	$temp['name'] = $name;
	$temp['message'] = $message;
	array_push($products,$temp);
}

mysqli_close($conn);
  echo json_encode($products);

?>