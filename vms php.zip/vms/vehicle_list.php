<?php

$con = new mysqli('localhost','root','');
$db = mysqli_select_db($con,'vms');
$username=$_POST['userid'];

$q = $con -> prepare("SELECT vehicle_id,model_name,years,reg_no,insurance_expdate,smoke_expdate,License_expdate,vehicle_type,rc_book,insurance_certificate,smoke_certificate,License,images,userid FROM addvehicle WHERE userid='$username'");
$q -> execute();

$q -> bind_result($vehicle_id, $model_name, $years, $reg_no, $insurance_expdate, $smoke_expdate,$License_expdate, $vehicle_type, $rc_book,$insurance_certificate,$smoke_certificate,$license,$images,$username);

$users = array();

while( $q -> fetch() ) {
    $temp = array();

    $temp['vehicle_id'] = $vehicle_id;
    $temp['model_name'] = $model_name;
    $temp['years'] = $years;
    $temp['reg_no'] = $reg_no;
    $temp['insurance_expdate'] = $insurance_expdate;
    $temp['smoke_expdate'] = $smoke_expdate;
    $temp['License_expdate'] = $License_expdate;
    $temp['vehicle_type'] = $vehicle_type;
    $temp['rc_book'] = $rc_book;
    $temp['insurance_certificate'] = $insurance_certificate;
    $temp['smoke_certificate'] = $smoke_certificate;
    $temp['License'] = $license;
    $temp['images'] = $images;
    $temp['userid'] = $username;

    array_push($users, $temp);
}

echo json_encode($users);

?>