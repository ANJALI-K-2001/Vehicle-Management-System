<?php
include('Config.php');


$username = $_POST['userid'];
$model_name = $_POST['model_name'];
$years = $_POST['years'];
$reg_no = $_POST['reg_no'];
$insurance_expdate = $_POST['insurance_expdate'];
$smoke_expdate = $_POST['smoke_expdate'];
$license = $_POST['License_expdate'];
$vehicle_type = $_POST['vehicle_type'];



$q = "INSERT INTO addvehicle (userid,model_name,years,reg_no,insurance_expdate,smoke_expdate,License_expdate,vehicle_type)VALUES('$username','$model_name','$years ','$reg_no','$insurance_expdate','$smoke_expdate','$license','$vehicle_type')";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['message'] = "Data insertion Successful";
}
else {
    $response['status'] = "0";
    $response['message'] = "Data insertion Failed" ;
}

echo json_encode($response);

?>