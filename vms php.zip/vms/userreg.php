<?php
include('Config.php');


$user = $_POST["username"];
$pass = $_POST["password"];
$name = $_POST["fullname"];
$phone = $_POST["phone_no"];
$email = $_POST["email"];
$address = $_POST["address"];
$license = $_POST["license_no"];
$gender = $_POST["gender"];




$q = "INSERT INTO users(username,password,fullname,phone_no,email,address,license_no,gender) VALUES ('$user', '$pass', '$name', '$phone', '$email', '$address', '$license', '$gender')";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['message'] = "Registration Successful";
}
else {
    $response['status'] = "0";
    $response['message'] = "Registration Failed" ;
}

echo json_encode($response);

?>