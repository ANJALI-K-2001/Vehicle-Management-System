<?php

include('Config.php');

$user = $_POST["Username"];
$pass = $_POST["Password"];


$q ="SELECT user_id,fullname,`phone_no`,email,`address`,`license_no`,gender FROM users WHERE username='$user' && password= '$pass' ";
$result = mysqli_query($con, $q);

$count = mysqli_num_rows($result);
$row=mysqli_fetch_row($result);

if($count > 0) {
    $response['status'] = "1";
    $response['message'] = "Login Successful";
    $response['user_id']=$row[0];
    $response['fullname']=$row[1];
    $response['phone_no']=$row[2];
    $response['email']=$row[3];
    $response['address']=$row[4];
    $response['License_no']=$row[5];
    $response['gender']=$row[6];


    
}
else {
    $response['status'] = "0";
    $response['message'] = "Incorrect username or password" ;
    $response['user_id']="";
    $response['fullname']="";
    $response['phone_no']="";
    $response['email']="";
    $response['address']="";
    $response['License_no']="";
    $response['gender']="";

}

echo json_encode($response);

?>