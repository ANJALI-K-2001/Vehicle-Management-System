<?php

include('Config.php');

$user = $_POST["Username"];
$pass = $_POST["Password"];


$q ="SELECT mechanic_id,username,password,fullname,phone_no,email,place,mechanic_type FROM mechanic WHERE username='$user' && password= '$pass' && s='1' ";
$result = mysqli_query($con, $q) or die(mysqli_error($con));
$row =mysqli_fetch_row($result);


if(mysqli_num_rows($result)>0) {
    $response['status'] = "1";
    $response['message'] = "Login Successful";
    $response['mechanic_id']=$row[0];
    $response['username']=$row[1];
    $response['password']=$row[2];
    $response['fullname']=$row[3];
    $response['phone_no']=$row[4];
    $response['email']=$row[5];
    $response['place']=$row[6];
    $response['mechanic_type']=$row[7];
   

}
else {
    $response['status'] = "0";
    $response['message'] = "Login Failed" ;
    $response['mechanic_id']="";
    $response['username']="";
    $response['password']="";
    $response['fullname']="";
    $response['phone_no']="";
    $response['email']="";
    $response['place']="";
    $response['mechanic_type']="";
}

echo json_encode($response);

?>