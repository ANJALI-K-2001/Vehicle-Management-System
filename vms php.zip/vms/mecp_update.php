<?php

include('Config.php');

$id = $_POST["mechanic_id"];
$user = $_POST["username"];
$name = $_POST["fullname"];
$phone = $_POST["phone_no"];
$email = $_POST["email"];
$place = $_POST["place"];



$q = "UPDATE mechanic SET username='$user', fullname='$name', phone_no='$phone', email='$email', place='$place' WHERE mechanic_id='$id' ";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['error'] = "Profile Updation Successfull";
}
else {
    $response['status'] = "0";
    $response['error'] = "Profile Updation Failed" ;
}

echo json_encode($response);

?>