<?php
include('Config.php');

$username = $_POST['userid'];
$model_name = $_POST['model_name'];
$years = $_POST['years'];
$reg_no = $_POST['reg_no'];
$vehicle_type = $_POST['vehicle_type'];
$km_drove = $_POST['km_drove'];
$mileage = $_POST['mileage'];
$rent_perday = $_POST['rent_perday'];
$rent_permonth = $_POST['rent_permonth'];


$q = "INSERT INTO rentvehicle (userid,model_name,years,reg_no,vehicle_type,km_drove,mileage,rent_perday,rent_permonth)VALUES('$username','$model_name','$years','$reg_no','$vehicle_type','$km_drove','$mileage','$rent_perday','$rent_permonth')";
$result = mysqli_query($con, $q)or die (mysqli_error($con));

if($result) {
    $response['status'] = "1";
    $response['message'] = "Data insertion Successful";
}
else {
    $response['status'] = "0";
    $response['message'] = "Data insertion Failed" ;
}

echo json_encode($response);

?>