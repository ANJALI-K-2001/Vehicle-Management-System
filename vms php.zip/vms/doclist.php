<?php

$con = new mysqli('localhost','root','');
$db = mysqli_select_db($con,'vms');
$userid=$_POST['userid'];

$q = $con -> prepare("SELECT vehicle_id,reg_no,insurance_expdate,smoke_expdate,License_expdate,vehicle_type,userid FROM addvehicle WHERE userid='$userid'");
$q -> execute();

$q -> bind_result($vehicle_id, $reg_no, $insurance_expdate, $smoke_expdate,$License_expdate, $vehicle_type,$userid);
$users = array();

while( $q -> fetch() ) {
    $temp = array();

    $temp['vehicle_id'] = $vehicle_id;
    $temp['reg_no'] = $reg_no;
    $temp['insurance_expdate'] = $insurance_expdate;
    $temp['smoke_expdate'] = $smoke_expdate;
    $temp['License_expdate'] = $License_expdate;
    $temp['vehicle_type'] = $vehicle_type;
    $temp['userid'] = $userid;

    array_push($users, $temp);
}

echo json_encode($users);

?>