<?php
include('Config.php');


$userid = $_POST['userid'];
$regno = $_POST['reg_no'];

$q = "DELETE  from addvehicle WHERE userid='$userid' && reg_no='$regno'";
$result = mysqli_query($con, $q)or die (mysqli_error($con));

if($result) {
    $response['status'] = "1";
    $response['message'] = "Data deletion Successful";
}
else {
    $response['status'] = "0";
    $response['message'] = "Data deletion Failed" ;
}

echo json_encode($response);

?>