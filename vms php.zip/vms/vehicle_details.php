<?php
include('Config.php');

$user = $_POST["username"];
$model = $_POST["model_name"];
$year = $_POST["year"];
$regno = $_POST["reg_no"];
$ins_expdate = $_POST["insurance_expdate"];
$smk_expdate = $_POST["smoke_expdate"];
$License_expdate=$_POST["License_expdate"];
$vehtype = $_POST["vehicle_type"];

$q= "INSERT INTO  VALUES ('', '$user', '$model', '$year', '$regno', '$ins_expdate', '$smk_expdate','$License_expdate','$vehtype')";

               $result=mysqli_query($con,$q);
                if($result)
                {
                	 $response['status'] = "1";
                   $response['message'] = "File uploaded successfully";
                }
                else {
                	$response['status'] = "0";
                  $response['message'] = "Data insertion failed";
                }
              
                
        echo json_encode($response);
    
?>