<?php

$con = new mysqli('localhost','root','');
$db = mysqli_select_db($con,'vms');
$username=$_POST['userid'];

$q = $con -> prepare("SELECT vehicle_id,model_name,years,reg_no,km_drove,mileage,rent_perday,rent_permonth,rc_book,vehicle_type,userid,images FROM rentvehicle");
$q -> execute();
$q -> bind_result($vehicle_id, $model_name, $years, $reg_no,$km_drove,$mileage,$rent_perday,$rent_permonth,$rc_book,$vehicle_type,$username,$images);

$users = array();

while( $q -> fetch() ) {
    $temp = array();

    $temp['vehicle_id'] = $vehicle_id;
    $temp['model_name'] = $model_name;
    $temp['years'] = $years;
    $temp['reg_no'] = $reg_no;
    $temp['km_drove'] = $km_drove;
    $temp['mileage'] = $mileage;
    $temp['rent_perday'] = $rent_perday;
    $temp['rent_permonth'] = $rent_permonth;
    $temp['rc_book'] = $rc_book;
    $temp['vehicle_type'] = $vehicle_type;
    $temp['userid'] = $username;
    $temp['images'] = $images;
    

    array_push($users, $temp);
}

echo json_encode($users);

?>