<?php
include('Config.php');

$name = $_POST["name"];
$messages = $_POST["message"];
$mech_id = $_POST["mech_id"];

$q = "INSERT INTO feedback VALUES ('', '$name', '$messages','$mech_id')";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['message'] = "Feedback send Successfully";
}
else {
    $response['status'] = "0";
    $response['message'] = " Failed to send Feedback " ;
}

echo json_encode($response);

?>