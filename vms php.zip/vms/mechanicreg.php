<?php

include('Config.php');

$user = $_POST["username"];
$pass = $_POST["password"];
$name = $_POST["fullname"];
$phone = $_POST["phone_no"];
$email = $_POST["email"];
$place = $_POST["place"];
$mectype = $_POST["mechanic_type"];
$latitude = $_POST["latitude"];
$longitude = $_POST["longitude"];
$s=$_POST["s"];


$q = "INSERT INTO mechanic (username,password,fullname,phone_no,email,place,mechanic_type,latitude,longitude,s)
 VALUES ('$user', '$pass', '$name', '$phone', '$email', '$place', '$mectype','$latitude','$longitude','0')";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['message'] = "Registration Successful";
}
else {
    $response['status'] = "0";
    $response['message'] = "Registration Failed" ;
}

echo json_encode($response);

?>