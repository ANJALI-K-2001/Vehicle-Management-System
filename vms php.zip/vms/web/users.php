<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Savari Admin</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <!--<meta name="keywords" content="Asap Cab Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />-->
    <script>
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }

    </script>
    <!-- //Meta tag Keywords -->
    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!-- Style-CSS -->
    <!-- font-awesome-icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome-icons -->
    <!-- /Fonts -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Khula:300,400,600,700,800" rel="stylesheet">
    <!-- //Fonts -->
</head>

<body>
    <!-- mian-content -->
    <div class="main-content" id="home">
        <div class="layer">
            <!-- header -->
            <header>
                <div class="container-fluid px-lg-5">
                    <!-- nav -->
                    <nav class="py-4 d-lg-flex">
                        <div id="logo">
                            <h1> <a href="index.html">Savari</a></h1>
                        </div>
                        <label for="drop" class="toggle">Menu</label>
                        <input type="checkbox" id="drop" />
                        <ul class="menu mt-2 ml-auto">
                            <li><a href="home.html">Home</a></li>
                           
                        </ul>
                    </nav>
                    <!-- //nav -->
                </div>
            </header>
            <!-- //header -->
            <div class="container">
                <!-- /banner -->
                <div class="banner-info-w3ls text-left">
                    <h3>Enjoy The Comfortable Trip</h3>
                    <div class="read-more">
                        <!--<a href="#about" class="read-more scroll btn">Read More </a> -->
                    </div>
                </div>
            </div>
            <!-- //banner -->
        </div>
    </div>
    <!--// mian-content -->
    
    
    
    <!--/mid-sec-->
    <section class="mid-sec py-5" id="menu">
        <div class="container py-lg-5">
            <div class="header pb-lg-3 pb-3 text-center">
                <h3 class="tittle mb-lg-3 mb-3">Users</h3>
            </div>
            <div class="row middile-inner-con mt-md-3">
                
                
                <table border="1" align="center"> 
                    <tr>
                    <td><h4>id</h4></td>
                    <td><h4>name</h4></td>
                    <td><h4>message</h4></td>
                    
                    <!--<td><h4>Action</h4></td>-->
                    </tr>     
                        
                    <?php
                    
                    include_once('config.php');
                    
                  	$query1="select * from appfeedback";
        	        $res1=mysqli_query($conn, $query1) or die("error".mysqli_error());
        	        while($row1=mysqli_fetch_array($res1))
        	        {
        	            $id = $row1['feedbackid'];
            	        $name = $row1['name'];
            	        $message = $row1['message'];
            	      
                        ?>
                    
                        <tr>
                        <td><?php echo $id;?></td>
                            <td><?php echo $name;?></td>
                            
                            <td><?php echo $message;?></td>
                            <!--<td><a href="delete_client.php?id=<?php echo $id;?>">Delete</a></td>-->
                            </tr>
                        <?php
        	        }
                    ?>
              
                </table>
                
                
            </div>
        </div>
    </section>
    <!--//mid-sec-->

    

</body>

</html>
