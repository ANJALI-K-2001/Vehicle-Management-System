<?php

include_once('config.php');

$id=$_GET['id'];
$query="DELETE FROM mechanic  WHERE mechanic_id='$id'";
$r=mysqli_query($conn, $query) or die(mysqli_error($conn));
if($r)
{
    ?>
    <script language="javascript">alert('Deleted Successfully');
    window.location.replace('home.html');
    </script>
    <?php
}

else
{
    ?>
    <script language="javascript">alert('Failed To Delete');</script>
    <?php
}


?>