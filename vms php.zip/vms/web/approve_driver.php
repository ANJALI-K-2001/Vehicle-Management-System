<?php

include_once('config.php');

$id=$_GET['id'];
$query="UPDATE mechanic SET s ='1' WHERE mechanic_id='$id'";
$r=mysqli_query($conn, $query) or die(mysqli_error($conn));
if($r)
{
    ?>
    <script language="javascript">alert('Approved Successfully');
    window.location.replace('home.html');
    </script>
    <?php
}

else
{
    ?>
    <script language="javascript">alert('Failed To Approve');</script>
    <?php
}


?>