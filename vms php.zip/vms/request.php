<?php
include('Config.php');


$id = $_POST["id"];
$status = $_POST["status"];
$user_id = $_POST["user_id"];
$username = $_POST["username"];
$fullname = $_POST["fullname"];
$phone_no = $_POST["phone_no"];
$mech_id = $_POST["mech_id"];
$mechname = $_POST["mechname"];
$mphone_no = $_POST["mphone_no"];


$q = "INSERT INTO requestmec(id,status,user_id,username,fullname,phone_no,mech_id,mechname,mphone_no) VALUES ('$id', '$status', '$user_id', '$username', '$fullname','$phone_no', '$mech_id', '$mechname', '$mphone_no')";
$result = mysqli_query($con, $q);

if($result) {
    $response['status'] = "1";
    $response['message'] = "Request Sent";
}
else {
    $response['status'] = "0";
    $response['message'] = "Request Sent Failed" ;
}

echo json_encode($response);

?>