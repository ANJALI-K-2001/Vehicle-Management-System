package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserRegisterActivity extends AppCompatActivity {

  EditText etName,etPhone,etEmail,etAddress,etLicense,etUsernameuser,etPassworduser;
  Button btnRegister;

    String status,message,url=Config.baseurl+"userreg.php";
    RadioGroup radio_gender;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);
        getSupportActionBar().hide();

        etName=findViewById(R.id.etFullname);
        etPhone=findViewById(R.id.etPhone);
        etEmail=findViewById(R.id.etEmail);
        etAddress=findViewById(R.id.etAddress);
        etLicense=findViewById(R.id.etLicense);
        etUsernameuser=findViewById(R.id.etUsername);
        etPassworduser=findViewById(R.id.etPasswordMech);


      btnRegister=findViewById(R.id.btnRegister1);
      btnRegister.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {

              setBtnRegister();
          }
      });
      radio_gender=findViewById((R.id.rd_MALE));
    }
    private void setBtnRegister() {
        final String Username = etUsernameuser.getText().toString();
        final String Password = etPassworduser.getText().toString();
        final String Email = etEmail.getText().toString();
        final String Phone = etPhone.getText().toString();
        final String Address = etAddress.getText().toString();
        final String License = etLicense.getText().toString();
        final String Fullname = etName.getText().toString();

        int id=radio_gender.getCheckedRadioButtonId();
        RadioButton rb=radio_gender.findViewById(id);
        final String Gender=rb.getText().toString();
        if (TextUtils.isEmpty(Fullname)) {
            etName.setError("Please enter Full name");
            etName.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Phone)) {
            etPhone.setError("Please enter Phone");
            etPhone.requestFocus();
            return;
        }
        if (!isPhoneValid(Phone)) {
            etPhone.setError("invalid Phone");
            etPhone.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(Email)) {
            etEmail.setError("Please enter Email");
            etEmail.requestFocus();
            return;
        }
        if (!isEmailValid(Email)) {
            etEmail.setError("invalid email");
            etEmail.requestFocus();
            return;
        }


        if (TextUtils.isEmpty(Address)) {
            etAddress.setError("Please enter Address");
            etAddress.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(License)) {
            etLicense.setError("Please enter License no");
            etLicense.requestFocus();
            return;
        } if (TextUtils.isEmpty(Username)) {
            etUsernameuser.setError("Please enter Username");
            etUsernameuser.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Password)) {
            etPassworduser.setError("Please enter Password");
            etPassworduser.requestFocus();
            return;
        }

        Config.showSimpleProgressDialog(this);
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
            Config.removeSimpleProgressDialog();

                        try {
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(UserRegisterActivity.this, message, Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else {
                                Toast.makeText(UserRegisterActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(UserRegisterActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username",Username);
                params.put("password", Password);
                params.put("email", Email);
                params.put("phone_no", Phone);
                params.put("gender", Gender);
                params.put("fullname", Fullname);
                params.put("address", Address);
                params.put("license_no", License);



                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }


    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    public static boolean isEmailValid(String Email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(Email).matches();
    }


}