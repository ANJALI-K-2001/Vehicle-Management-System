package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddVehicleActivity extends AppCompatActivity {
    String Username;
    EditText etModel, etYear, etRegno, etInsurance, etSmoke, etLicense,etvehicletype;
    Button btnproceed;
    String status, message, url = Config.baseurl + "add_vehicle.php", Model, Smoke,License, Insurance, Regno, Year, vehicletype;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_vehicles);

        Username = new UserSession(this).getUserDetails().get("id");
        etModel = findViewById(R.id.etModelname);
        etYear = findViewById(R.id.etYear);
        etRegno = findViewById(R.id.etRegno);
        etInsurance = findViewById(R.id.et_insurance);
        etSmoke = findViewById(R.id.et_smoke);
        etLicense=findViewById(R.id.et_license);
        etvehicletype = findViewById(R.id.etvehicletype);
        btnproceed = findViewById(R.id.btn);
        btnproceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setbtnproceed();
            }
        });
    }

    private void setbtnproceed() {
        Model = etModel.getText().toString();
        Year = etYear.getText().toString();
        Regno = etRegno.getText().toString();
        Insurance = etInsurance.getText().toString();
        Smoke = etSmoke.getText().toString();
        License=etLicense.getText().toString();
        vehicletype = etvehicletype.getText().toString();


        if (TextUtils.isEmpty(Model)) {
            etModel.setError("Please enter Model name");
            etModel.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Year)) {
            etYear.setError("Please enter year");
            etYear.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Regno)) {
            etRegno.setError("Please enter Register no");
            etRegno.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(Insurance)) {
            etInsurance.setError("Please enter insurance expiry date");
            etInsurance.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(Smoke)) {
            etSmoke.setError("Please enter smoke expiry date");
            etSmoke.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(License)) {
            etLicense.setError("Please enter Driving License expiry date");
            etLicense.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(vehicletype)) {
            etvehicletype.setError("Please enter vehicle type");
            etvehicletype.requestFocus();
            return;
        }
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Config.removeSimpleProgressDialog();

                        try {
                            Toast.makeText(AddVehicleActivity.this, response, Toast.LENGTH_SHORT).show();
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(AddVehicleActivity.this, message, Toast.LENGTH_SHORT).show();
                                Intent i=new Intent(getApplicationContext(),AddVehicle2Activity.class);
                                i.putExtra("regno",Regno);
                                startActivity(i);
                                finish();
                            } else {
                                Toast.makeText(AddVehicleActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(AddVehicleActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //add string parameters
                params.put("userid", Username);
                params.put("model_name", Model);
                params.put("years", Year);
                params.put("reg_no", Regno);
                params.put("insurance_expdate", Insurance);
                params.put("smoke_expdate", Smoke);
                params.put("License_expdate", License);
                params.put("vehicle_type", vehicletype);

                return params;
            }

        };
        RequestQueue rqueue = Volley.newRequestQueue(AddVehicleActivity.this);
        rqueue.add(request);

    }
}