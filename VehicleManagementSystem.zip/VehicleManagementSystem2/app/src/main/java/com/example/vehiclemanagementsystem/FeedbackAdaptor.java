package com.example.vehiclemanagementsystem;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FeedbackAdaptor extends RecyclerView.Adapter<FeedbackAdaptor.MyViewHolder> {
    ArrayList<FeedbackModel> data;
    Context c;
    LayoutInflater inflater;

    public FeedbackAdaptor(Context c, ArrayList<FeedbackModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }
    @NonNull
    @Override
    public FeedbackAdaptor.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_feedback, parent, false);
        FeedbackAdaptor.MyViewHolder holder = new FeedbackAdaptor.MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull FeedbackAdaptor.MyViewHolder holder, int position) {
        final FeedbackModel model = data.get(position);

        holder.tvName.setText("Name: " + model.getName());
        holder.tvMessage.setText("Message: " + model.getMessage());

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(c, FeedbackAdaptor.class);
                i.putExtra("name", model.getName());
                i.putExtra("message", model.getMessage());
                c.startActivity(i);

            }
        });
    }


    @Override
    public int getItemCount() { return data.size(); }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName,tvMessage ;

        CardView card;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tvName);
            tvMessage = itemView.findViewById(R.id.tvMessage);

            card = itemView.findViewById(R.id.feedcard);
        }
    }
    }



