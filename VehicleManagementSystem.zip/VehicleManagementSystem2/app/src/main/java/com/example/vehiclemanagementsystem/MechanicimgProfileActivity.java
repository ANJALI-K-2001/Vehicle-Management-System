package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

public class MechanicimgProfileActivity extends AppCompatActivity {
    EditText Username,mname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanicimg_profile);

        Username=findViewById(R.id.mechname);
        mname=findViewById(R.id.mechusername);

    }
}