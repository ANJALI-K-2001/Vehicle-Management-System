package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UserpEditActivity extends AppCompatActivity {
    EditText et_fullname,etUsername,etPhone,et_email,et_license,et_gender,et_address;
    Button Btnupdate;
    String status,message,url=Config.baseurl+"userp_update.php",fullname,username,phone,email,license,gender,address;
    String user_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_pedit);




        et_fullname = findViewById(R.id.et_Fullname);
        etUsername = findViewById(R.id.etUsername);
        etPhone = findViewById(R.id.etPhone);
        et_email = findViewById(R.id.et_email);
        et_license = findViewById(R.id.et_license);
        et_gender = findViewById(R.id.et_gender);
        et_address = findViewById(R.id.et_address);

        Btnupdate = findViewById(R.id.btnupdate);
        Btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            UserpEditActivity();
            }

        });
        user_id =  new UserSession(UserpEditActivity.this).getUserDetails().get("id");


    }

    public void UserpEditActivity() {

        final String fullname= et_fullname.getText().toString();
        final String username = etUsername.getText().toString();
        final String phone = etPhone.getText().toString();
        final String email = et_email.getText().toString();
        final String license= et_license.getText().toString();
        final String gender = et_gender.getText().toString();
        final String address= et_address.getText().toString();



        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Config.removeSimpleProgressDialog();

                        try {
                            Toast.makeText(UserpEditActivity.this, response, Toast.LENGTH_SHORT).show();
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(UserpEditActivity.this,"updation successful", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(UserpEditActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(UserpEditActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //add string parameters
                params.put("user_id",   user_id);
                params.put("username", username);
                params.put("fullname", fullname);
                params.put("phone_no", phone);
                params.put("email", email);
                params.put("address", address);
                params.put("license_no", license);
                params.put("gender", gender);

                return params;
            }

        };
        RequestQueue rqueue = Volley.newRequestQueue(UserpEditActivity.this);
        rqueue.add(request);

    }
}




