package com.example.vehiclemanagementsystem.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vehiclemanagementsystem.ListVehicleActivity;
import com.example.vehiclemanagementsystem.R;
import com.example.vehiclemanagementsystem.RentListActivity;
import com.example.vehiclemanagementsystem.RentVehicleActivity;

public class RentFragment extends Fragment {
        CardView availrent,uprent;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_rent, container, false);
        availrent=root.findViewById(R.id.cvrent);
        uprent=root.findViewById(R.id.cvup);

        availrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), RentListActivity.class);
                startActivity(i);
            }
        });



        uprent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(), RentVehicleActivity.class);
                startActivity(i);
            }
        });





        return root;
    }
}