package com.example.vehiclemanagementsystem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import mumayank.com.airlocationlibrary.AirLocation;

public class ListMechanicActivity extends AppCompatActivity {

    String url = Config.baseurl + "mec_list.php";
    ArrayList<MechanicModel> list;
    RecyclerView recycler;
    FloatingActionButton floatingmechbtn;
    SearchView searchView;
    MechanicAdapter mechanicAdapter;
    AirLocation airLocation;
    String latitude, longitude;

    String status,datas;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) this.getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(this.getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
               mechanicAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                mechanicAdapter.getFilter().filter(query);
                return false;
            }
        });
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_mechanic);
        recycler = findViewById(R.id.recycler);

        fetchlocation();

    }
    private void fetchlocation() {

        airLocation = new AirLocation(ListMechanicActivity.this, true, true, new AirLocation.Callbacks() {
            @Override
            public void onSuccess(Location location) {
                Toast.makeText(getApplicationContext(), "location fetched successfully", Toast.LENGTH_SHORT).show();
                double lat, lng;
                lat = location.getLatitude();
                lng = location.getLongitude();
                latitude = Double.toString(lat);
                longitude = Double.toString(lng);
                Toast.makeText(getApplicationContext(), latitude+longitude, Toast.LENGTH_SHORT).show();
                fetchData();
//                checkPermission();
            }

            @Override
            public void onFailed(AirLocation.LocationFailedEnum locationFailedEnum) {
                Toast.makeText(getApplicationContext(), "location fetching failed.please check your internet connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(ListMechanicActivity.this, new String[]{Manifest.permission.SEND_SMS}, 2);
        } else {
//            uploadLocation();
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        airLocation.onActivityResult(requestCode, resultCode, data);
    }


    private void fetchData() {

        list=new ArrayList<>();

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(ListMechanicActivity.this, response, Toast.LENGTH_SHORT).show();

                        try {

                            JSONObject jsonObject = new JSONObject(response);
                            status = jsonObject.getString("status");
                            datas = jsonObject.getString("data");

                            if (status.equals("1")) {
//                                Toast.makeText(getApplicationContext(), datas, Toast.LENGTH_SHORT).show();

                                JSONArray data = new JSONArray(datas);
                                for (int i = 0; i < data.length(); i++) {
                                    JSONObject user = data.getJSONObject(i);


                                    list.add(new MechanicModel(
                                            user.getString("mechanic_id"),
                                            user.getString("username"),
                                            user.getString("password"),
                                            user.getString("fullname"),
                                            user.getString("phone_no"),
                                            user.getString("email"),
                                            user.getString("place"),
                                            user.getString("mechanic_type"),
                                            user.getString("distance")

                                    ));
                                }

                            }
                        }catch (JSONException e) {
                            e.printStackTrace();
                        }

                         mechanicAdapter  = new MechanicAdapter(ListMechanicActivity.this, list);
                        recycler.setHasFixedSize(true);
                        recycler.setAdapter(mechanicAdapter);
                        recycler.setLayoutManager(new LinearLayoutManager(ListMechanicActivity.this, LinearLayoutManager.VERTICAL, false));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(ListMechanicActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //add string parameters
                params.put("lat", latitude);
                params.put("lng", longitude);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}