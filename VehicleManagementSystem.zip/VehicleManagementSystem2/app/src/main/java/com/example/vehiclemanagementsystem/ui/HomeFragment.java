package com.example.vehiclemanagementsystem.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.vehiclemanagementsystem.AddVehicleActivity;
import com.example.vehiclemanagementsystem.Config;
import com.example.vehiclemanagementsystem.ListMechanicActivity;
import com.example.vehiclemanagementsystem.ListVehicleActivity;
import com.example.vehiclemanagementsystem.MechanicAdapter;
import com.example.vehiclemanagementsystem.MechanicModel;
import com.example.vehiclemanagementsystem.MechanicProfileActivity;
import com.example.vehiclemanagementsystem.R;
import com.example.vehiclemanagementsystem.UserSession;
import com.example.vehiclemanagementsystem.UserpEditActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class HomeFragment extends Fragment {

    LinearLayout vehicle, mechanic;
    RecyclerView recyclerVehicle;
    TextView etname, etemail, etphone;
    ArrayList<MechanicModel> list_Mechanic;
    FloatingActionButton floatingbtn;
    String mechanic_url = Config.baseurl + "mec_list.php";
    String username,email,phone;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);
        vehicle = root.findViewById(R.id.layoutVehicle);
        mechanic = root.findViewById(R.id.layoutMechanic);
        etname = root.findViewById(R.id.nameid);
        etemail = root.findViewById(R.id.idemail);
        etphone = root.findViewById(R.id.phoneid);


        floatingbtn = root.findViewById(R.id.btn_Edit);
        recyclerVehicle = root.findViewById(R.id.recycler_vehicle);


       HashMap<String,String>user=new UserSession(getActivity()).getUserDetails();
        username=user.get("Username");
        email=user.get("Email");
        phone=user.get("Phone");

        etname.setText(username);
        etemail.setText(email);
        etphone.setText(phone);

        floatingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), UserpEditActivity.class);
                startActivity(i);
            }
        });


        vehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "....", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getActivity(), ListVehicleActivity.class);
                startActivity(i);
            }
        });

        mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "....", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getActivity(), ListMechanicActivity.class);
                startActivity(i);
            }
        });









        fetchMechanic();
        return root;
    }


    private void fetchMechanic() {
        list_Mechanic = new ArrayList<>();

        Config.showSimpleProgressDialog(getActivity());

        StringRequest request = new StringRequest(Request.Method.GET, mechanic_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Config.removeSimpleProgressDialog();
                        try {
                            JSONArray data = new JSONArray(response);

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject user = data.getJSONObject(i);


                                list_Mechanic.add(new MechanicModel(
                                        user.getString("id"),
                                        user.getString("username"),
                                        user.getString("password"),
                                        user.getString("fullname"),
                                        user.getString("phone"),
                                        user.getString("email"),
                                        user.getString("place"),
                                        user.getString("mechanictype"),
                                        null

                                ));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        MechanicAdapter adapter = new MechanicAdapter(getActivity(), list_Mechanic);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(request);
    }

}