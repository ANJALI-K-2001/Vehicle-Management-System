package com.example.vehiclemanagementsystem;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import mumayank.com.airlocationlibrary.AirLocation;


public class MechanicAdapter extends RecyclerView.Adapter<MechanicAdapter.MyViewHolder>implements Filterable {

    ArrayList<MechanicModel> data;
    Context c;
    LayoutInflater inflater;
    ArrayList<MechanicModel>dataModelArrayListFiltered;
    AirLocation airLocation;
    String latitude,longitude;

    public MechanicAdapter(Context c, ArrayList<MechanicModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayListFiltered=data;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_mechanic, parent, false);
        MyViewHolder holder = new MyViewHolder(v);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final MechanicModel model = dataModelArrayListFiltered.get(position);

        holder.tvname.setText(model.getFullname());
        holder.tvplace.setText("Place: " + model.getPlace());
        holder.tvPhone.setText("Phone: " + model.getPhone());
        holder.tvMechanictype.setText("Type: " + model.getMechanictype());
        holder.dis.setText("Distance: " + model.getDistance());

        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + model.getPhone()));
                c.startActivity(intent);
            }
        });


        holder.request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                request(model.getId(), model.getFullname(), model.getPhone(), model.getPlace(), model.getMechanictype());
                fetchlocation(model.getPhone());


            }
        });
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(c, MechFeedbackActivity.class);
                i.putExtra("id", model.getId());
                c.startActivity(i);

            }
        });
    }

    private void fetchlocation(final String phone) {
        airLocation = new AirLocation((Activity) c, true, true, new AirLocation.Callbacks() {
            @Override
            public void onSuccess(Location location) {
                Toast.makeText(c, "location fetched successfully", Toast.LENGTH_SHORT).show();
                double lat, lng;
                lat = location.getLatitude();
                lng = location.getLongitude();
                latitude = Double.toString(lat);
                longitude= Double.toString(lng);
                sendsms(phone,latitude,longitude);
                checkPermission();
            }

            @Override
            public void onFailed(AirLocation.LocationFailedEnum locationFailedEnum) {
                Toast.makeText(c, "location fetching failed.please check your internet connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions((Activity) c, new String[]{Manifest.permission.SEND_SMS}, 2);
        } else {
            uploadLocation();
        }
    }

    private void uploadLocation() {
        String url=Config.baseurl+"fetch_loc.php";
        final String[] status = new String[1];
        final String[] message = new String[1];
        final String id;

        id = new UserSession(c).getUserDetails().get("id");



        StringRequest request = new StringRequest(Request.Method.POST,url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Toast.makeText(c, response, Toast.LENGTH_SHORT).show();

                    JSONObject jsonobject = new JSONObject(response);
                    status[0] = jsonobject.getString("status");
                    message[0] = jsonobject.getString("message");

                    if (status[0].equals("1")) {
                        Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();


                    } else {
                        Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", id);
                map.put("latitude",latitude);
                map.put("longitude",longitude);

                return map;
            }
        };
        RequestQueue requestqueue = Volley.newRequestQueue(c);
        requestqueue.add(request);

    }

//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        airLocation.onActivityResult(requestCode, resultCode, data);
//    }

    private void request(final String id, final String fullname, final String phone, String place, String mechanictype) {
        final String[] status = new String[1];
        final String[] message = new String[1];
        String URL = Config.baseurl + "request.php";
        final String st = "request";


        final String Username, ids, Fullname, phones, address;

        Username = new UserSession(c).getUserDetails().get("Username");
        ids = new UserSession(c).getUserDetails().get("id");
        Fullname = new UserSession(c).getUserDetails().get("Fullname");
        phones = new UserSession(c).getUserDetails().get("Phone");
        address = new UserSession(c).getUserDetails().get("Address");

        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Config.removeSimpleProgressDialog();

                        try {
                            Toast.makeText(c, response, Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status[0] = data.getString("status");
                            message[0] = data.getString("message");


                            if (status[0].equals("1")) {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();


                            } else {
                                Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", Username);

                params.put("user_id", ids);
                params.put("fullname", Fullname);
               // params.put("userplace", address);
                params.put("phone_no", phones);
                params.put("mech_id", id);
                params.put("mechname", fullname);
                params.put("mphone_no", phone);
                params.put("status", st);


                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(request);

    }

    private void sendsms(String phone, String latitude, String longitude) {
        String msg="Welcome to VMS app , we need your help... Please Click on the link to get my current location.\n http://maps.google.com/maps?z=18&q="+latitude +","+longitude;
        SmsManager smsManager=SmsManager.getDefault();
        smsManager.sendTextMessage(phone,null,msg,null,null);


    }


    @Override
    public int getItemCount() {
        return dataModelArrayListFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataModelArrayListFiltered = data;
                } else {
                    ArrayList<MechanicModel> filteredList = new ArrayList<>();
                    for (MechanicModel row : data) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getPlace().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getPlace().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataModelArrayListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataModelArrayListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults (CharSequence constraint, FilterResults results){
//            dataModelArrayListFiltered.clear();
//            dataModelArrayListFiltered.addAll((ArrayList) results.values);

                notifyDataSetChanged();
            }
        };
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvname, tvPhone, tvMechanictype, tvplace,dis;
        ImageView img;
        CardView card;
        Button call, request;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvname = itemView.findViewById(R.id.tvname);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvMechanictype = itemView.findViewById(R.id.tvmechanictype);
            tvplace = itemView.findViewById(R.id.tvplace);
            img = itemView.findViewById(R.id.img);
            card = itemView.findViewById(R.id.card);
            call = itemView.findViewById(R.id.btncall);
            request = itemView.findViewById(R.id.btnrequest);
            dis = itemView.findViewById(R.id.tvdis);
        }
    }
}

