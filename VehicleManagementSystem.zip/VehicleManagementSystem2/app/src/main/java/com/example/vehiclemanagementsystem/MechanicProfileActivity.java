package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.se.omapi.Session;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MechanicProfileActivity extends AppCompatActivity {
    String Mechanic_id;
    EditText etname,etphone, etmail, etplace,etmechtype;
    FloatingActionButton floatingbtn;

    String name,phone,email,place,mectype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_profile);
        etname = findViewById(R.id.fullnametxt);
        etphone = findViewById(R.id.phonenumbertxt);
        etmail = findViewById(R.id.emailtxt);
        etplace = findViewById(R.id.placetxt);
        etmechtype = findViewById(R.id.mechanictypetxt);

        floatingbtn = findViewById(R.id.btn_edit);
        floatingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MechanicEditProfileActivity.class);
                startActivity(i);

            }
        });

        Mechanic_id = new MechSession(this).getMechDetails().get("mechanic_id");


        name = new MechSession(MechanicProfileActivity.this).getMechDetails().get("username");
        etname.setText(name);

        phone = new MechSession(MechanicProfileActivity.this).getMechDetails().get("phone");
        etphone.setText(phone);

        email = new MechSession(MechanicProfileActivity.this).getMechDetails().get("email");
        etmail.setText(email);

        place= new MechSession(MechanicProfileActivity.this).getMechDetails().get("place");
        etplace.setText(place);

        mectype = new MechSession(MechanicProfileActivity.this).getMechDetails().get("mechanic_type");
        etmechtype.setText(mectype);

    }
}
