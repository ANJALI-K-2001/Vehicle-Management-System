package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RentVehicleActivity extends AppCompatActivity {
    String Username;
    EditText etModel, etYear, etRegno,etvehicletype,etkilometer,etMileage,etRentperday,etRentpermonth;
    Button btnproceed;
    String status, message, url = Config.baseurl + "rent_vehicle.php", Model, Regno, Year, vehicletype,kilometer,Mileage,Rentperday,Rentpermonth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent_vehicle);
        Username = new UserSession(this).getUserDetails().get("id");
        etModel = findViewById(R.id.etModelname);
        etYear = findViewById(R.id.etYear);
        etRegno = findViewById(R.id.etRegno);
        etvehicletype = findViewById(R.id.etvehicletype);
        etkilometer=findViewById(R.id.et_km);
        etMileage=findViewById(R.id.et_mileage);
        etRentperday=findViewById(R.id.et_rentpday);
        etRentpermonth=findViewById(R.id.et_rentpmonth);
        btnproceed = findViewById(R.id.btn);
        btnproceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setbtnproceed();
            }
        });
    }
            private void setbtnproceed() {
                Model = etModel.getText().toString();
                Year = etYear.getText().toString();
                Regno = etRegno.getText().toString();
                vehicletype = etvehicletype.getText().toString();
                kilometer = etkilometer.getText().toString();
                Mileage = etMileage.getText().toString();
                Rentperday = etRentperday.getText().toString();
                Rentpermonth = etRentpermonth.getText().toString();

                if (TextUtils.isEmpty(Model)) {
                    etModel.setError("Please enter Model name");
                    etModel.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(Year)) {
                    etYear.setError("Please enter year");
                    etYear.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(Regno)) {
                    etRegno.setError("Please enter Register no");
                    etRegno.requestFocus();
                    return;
                }


                if (TextUtils.isEmpty(vehicletype)) {
                    etvehicletype.setError("Please enter vehicle type");
                    etvehicletype.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(kilometer)) {
                    etkilometer.setError("Please enter Kilometer Drove");
                    etkilometer.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(Mileage)) {
                    etMileage.setError("Please enter vehicle Mileage");
                    etMileage.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(Rentperday)) {
                    etRentperday.setError("Please enter Rent per Day");
                    etRentperday.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(Rentpermonth)) {
                    etRentpermonth.setError("Please enter Rentpermonth");
                    etRentpermonth.requestFocus();
                    return;
                }

                StringRequest request = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Config.removeSimpleProgressDialog();

                                try {
                                    Toast.makeText(RentVehicleActivity.this, response, Toast.LENGTH_SHORT).show();
                                    JSONObject data = new JSONObject(response);
                                    status = data.getString("status");
                                    message = data.getString("message");

                                    if (status.equals("1")) {
                                        Toast.makeText(RentVehicleActivity.this, message, Toast.LENGTH_SHORT).show();
                                        Intent i = new Intent(getApplicationContext(), RentDocActivity.class);
                                        i.putExtra("regno", Regno);
                                        startActivity(i);
                                        finish();
                                    } else {
                                        Toast.makeText(RentVehicleActivity.this, message, Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Config.removeSimpleProgressDialog();
                                Toast.makeText(RentVehicleActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }) {

                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        //add string parameters
                        params.put("userid", Username);
                        params.put("model_name", Model);
                        params.put("years", Year);
                        params.put("reg_no", Regno);
                        params.put("vehicle_type", vehicletype);
                        params.put("km_drove", kilometer);
                        params.put("mileage", Mileage);
                        params.put("rent_perday", Rentperday);
                        params.put("rent_permonth", Rentpermonth);
                        return params;
                    }

                };

                RequestQueue rqueue = Volley.newRequestQueue(RentVehicleActivity.this);
                rqueue.add(request);

    }
        }