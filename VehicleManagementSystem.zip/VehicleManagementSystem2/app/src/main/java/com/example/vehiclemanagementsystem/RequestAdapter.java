package com.example.vehiclemanagementsystem;

import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.MyViewHolder> {

    ArrayList<RequestModel> data;
    Context c;
    LayoutInflater inflater;

    public RequestAdapter(Context c, ArrayList<RequestModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_request, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final RequestModel model = data.get(position);

        holder.userid.setText("Userid : " + model.getUser_id());
        holder.username.setText("Username: " + model.getUsername());
        holder.phoneno.setText("Phone no: " + model.getPhone_no());
        holder.btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               send(model.getPhone_no());
            }
        });



//        if (!TextUtils.isEmpty(model.getImages())) {
//            Picasso.get()
//                    .load(model.getImages())
//                    .into(holder.img);
//        }

//        holder.card.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(c, VehActivity.class);
//                i.putExtra("userid", model.getUser_id());
//                i.putExtra("Username", model.getUsername());
//                i.putExtra("Phoneno", model.getPhoneno());
//
//                c.startActivity(i);
//            }
//        });
    }

    private void send(String phone_no) {
        String mechname;
        HashMap<String,String>user=new MechSession(c).getMechDetails();
        mechname=user.get("username");
        String msg="Welcome to vms app . Your request has been confirmed "  +mechname+ "\n"+ "take your vehicle" ;
        SmsManager smsManager=SmsManager.getDefault();
        smsManager.sendTextMessage(phone_no,null,msg,null,null);

    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView userid,username,phoneno;
Button btnConfirm;
        CardView card;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            userid = itemView.findViewById(R.id.userid);
            username= itemView.findViewById(R.id.username);
            btnConfirm= itemView.findViewById(R.id.confirm);
            phoneno= itemView.findViewById(R.id.Phoneno);
            card = itemView.findViewById(R.id.card);
        }
    }

}




