package com.example.vehiclemanagementsystem.Exp;

public class Expdata {
    String vehicle_id,reg_no,insurance_expdate,smoke_expdate,License_expdate,vehicle_type,userid;

    public Expdata(String vehicle_id, String reg_no, String insurance_expdate, String smoke_expdate, String license_expdate, String vehicle_type, String userid) {
        this.vehicle_id = vehicle_id;
        this.reg_no = reg_no;
        this.insurance_expdate = insurance_expdate;
        this.smoke_expdate = smoke_expdate;
        License_expdate = license_expdate;
        this.vehicle_type = vehicle_type;
        this.userid = userid;
    }

    public String getVehicle_id() {
        return vehicle_id;
    }

    public String getReg_no() {
        return reg_no;
    }

    public String getInsurance_expdate() {
        return insurance_expdate;
    }

    public String getSmoke_expdate() {
        return smoke_expdate;
    }

    public String getLicense_expdate() {
        return License_expdate;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public String getUserid() {
        return userid;
    }
}
