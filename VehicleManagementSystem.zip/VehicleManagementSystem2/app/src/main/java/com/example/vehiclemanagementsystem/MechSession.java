package com.example.vehiclemanagementsystem;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class MechSession {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "Mech";

    public MechSession(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createLoginSession(String id,String Username,String Password,String Fullname,String Phone,String Email,String Place,String Mechanic_type){
        editor.putString("mechanic_id", id);
        editor.putString("username", Username);
        editor.putString("password", Password);
        editor.putString("fullname", Fullname);
        editor.putString("phone", Phone);
        editor.putString("email", Email);
        editor.putString("place", Place);
        editor.putString("mechanic_type", Mechanic_type);

        editor.commit();
    }

    public HashMap<String, String> getMechDetails(){
        HashMap<String, String> Mech = new HashMap<>();
        Mech.put("mechanic_id", pref.getString("mechanic_id", null));
        Mech.put("username", pref.getString("username", null));
        Mech.put("password", pref.getString("password", null));
        Mech.put("fullname", pref.getString("fullname", null));
        Mech.put("phone", pref.getString("phone", null));
        Mech.put("email", pref.getString("email", null));
        Mech.put("place", pref.getString("place", null));
        Mech.put("mechanic_type", pref.getString("mechanic_type", null));

        return Mech;
    }

}

