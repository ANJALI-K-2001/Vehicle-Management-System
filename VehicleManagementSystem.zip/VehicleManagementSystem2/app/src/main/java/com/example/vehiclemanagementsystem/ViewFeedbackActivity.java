package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ViewFeedbackActivity extends AppCompatActivity {
    String url = Config.baseurl + "list_feedback.php ";
    ArrayList<FeedbackModel> feedlist;
    String Mechanic_id;
    RecyclerView recycler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_feedback);
        recycler = findViewById(R.id.recycler);
        Mechanic_id = new MechSession(this).getMechDetails().get("mechanic_id");
        Toast.makeText(getApplicationContext(), Mechanic_id, Toast.LENGTH_SHORT).show();
        fetchData();
    }
    private void fetchData() {
        Config.showSimpleProgressDialog(this );

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        feedlist = new ArrayList<>();


                        Config.removeSimpleProgressDialog();
                        try {
                            Toast.makeText(ViewFeedbackActivity.this, response, Toast.LENGTH_SHORT).show();

                            JSONArray data = new JSONArray(response);

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject user = data.getJSONObject(i);


                                feedlist.add(new FeedbackModel(
                                        user.getString("name"),
                                        user.getString("message")
                                        ));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        FeedbackAdaptor adapter = new FeedbackAdaptor(ViewFeedbackActivity.this, feedlist);
                        recycler.setHasFixedSize(true);
                        recycler.setAdapter(adapter);
                        recycler.setLayoutManager(new LinearLayoutManager(ViewFeedbackActivity.this, LinearLayoutManager.VERTICAL, false));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(ViewFeedbackActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("mech_id",Mechanic_id);

                return params;
            }
        };
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}

