package com.example.vehiclemanagementsystem.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.vehiclemanagementsystem.Config;
import com.example.vehiclemanagementsystem.MechanicRegisterActivity;
import com.example.vehiclemanagementsystem.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class FeedbackFragment extends Fragment {
    EditText etname, etmessage;
    Button proceed;
    String url = Config.baseurl + "app_feedback.php";
    String status, message;
    String name, feedmessage;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_feedback, container, false);

        etname = root.findViewById(R.id.idname);
        etmessage = root.findViewById(R.id.idmessage);
        proceed = root.findViewById(R.id.btn);
        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFeedbackFragment();
            }
        });
        return root;
    }
        private void setFeedbackFragment () {
            name = etname.getText().toString();
            feedmessage = etmessage.getText().toString();


            if (TextUtils.isEmpty(name)) {
                etname.setError("Please enter name");
                etname.requestFocus();
                return;
            }
            if (TextUtils.isEmpty(feedmessage)) {
                etmessage.setError("Please enter Message");
                etmessage.requestFocus();
                return;
            }

            Config.showSimpleProgressDialog(getActivity());
            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Config.removeSimpleProgressDialog();

                            try {
                                //JSON Parsing
                                JSONObject data = new JSONObject(response);
                                status = data.getString("status");
                                message = data.getString("message");

                                if (status.equals("1")) {
                                    Toast.makeText(getActivity(),"Feedback send Successfully" , Toast.LENGTH_SHORT).show();

                                } else {
                                    Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Config.removeSimpleProgressDialog();
                            Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                        }

                    }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("name", name);
                    params.put("message", feedmessage);

                    return params;
                }
            };

            RequestQueue queue = Volley.newRequestQueue(getActivity());
            queue.add(request);

        }

    }




