package com.example.vehiclemanagementsystem;

public class RentModel {
    String vehicle_id, model_name, years, reg_no,km_drove,mileage,rent_perday,rent_permonth,rc_book,vehicle_type, username,images ;


    public RentModel(String vehicle_id, String model_name, String years, String reg_no,String km_drove, String mileage,String rent_perday,String rent_permonth, String rc_book,String vehicle_type,String username,String images) {
        this.vehicle_id = vehicle_id;
        this.model_name = model_name;
        this.years = years;
        this.reg_no = reg_no;
        this.km_drove = km_drove;
        this.mileage= mileage;
        this.rent_perday = rent_perday;
        this.rent_permonth = rent_permonth;
        this.rc_book = rc_book;
        this.vehicle_type = vehicle_type;
        this.username = username;
        this.images = images;
        }

public String getVehicle_id() {
        return vehicle_id;
        }

public String getModel_name() {
        return model_name;
        }

public String getYears() {
        return years;
        }

public String getReg_no() {
        return reg_no;
        }

    public String getKm_drove() {
        return km_drove;
    }

    public String getmileage() {
        return mileage;
    }
    public String getRent_perday() {
        return rent_perday;
    }
    public String getRent_permonth() {
        return rent_permonth;
    }
    public String getRc_book() {
        return rc_book;
    }


    public String getVehicle_type() {
        return vehicle_type;
        }

    public String getUsername() {
        return username;
    }

        public String getImages() {
        return images;
        }


        }
