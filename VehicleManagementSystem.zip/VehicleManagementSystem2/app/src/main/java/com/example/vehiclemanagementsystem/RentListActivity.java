package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RentListActivity extends AppCompatActivity {
        String url = Config.baseurl + "rentlist.php";
        String Username;
        ArrayList<RentModel>list;
        RecyclerView recycler;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_rent_list);
            recycler = findViewById(R.id.recycler);
            fetchData();
            Username = new UserSession(this).getUserDetails().get("id");


        }


        private void fetchData() {
            list = new ArrayList<>();

            Config.showSimpleProgressDialog(this );

            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Config.removeSimpleProgressDialog();
                            try {
                                JSONArray data = new JSONArray(response);

                                for (int i = 0; i < data.length(); i++) {
                                    JSONObject user = data.getJSONObject(i);


                                    list.add(new RentModel(
                                            user.getString("vehicle_id"),
                                            user.getString("model_name"),
                                            user.getString("years"),
                                            user.getString("reg_no"),
                                            user.getString("km_drove"),
                                            user.getString("mileage"),
                                            user.getString("rent_perday"),
                                            user.getString("rent_permonth"),
                                            user.getString("rc_book"),
                                            user.getString("vehicle_type"),
                                            user.getString("userid"),
                                            user.getString("images")
                                    ));
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            RentAdapter adapter = new RentAdapter(com.example.vehiclemanagementsystem.RentListActivity.this,list);
                            recycler.setHasFixedSize(true);
                            recycler.setAdapter(adapter);
                            recycler.setLayoutManager(new LinearLayoutManager(com.example.vehiclemanagementsystem.RentListActivity.this, LinearLayoutManager.VERTICAL, false));
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Config.removeSimpleProgressDialog();
                            Toast.makeText(com.example.vehiclemanagementsystem.RentListActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    //add string parameters
                    params.put("userid", Username);
                    return params;
                }
            };

            RequestQueue queue = Volley.newRequestQueue(this);
            queue.add(request);
        }


    }
