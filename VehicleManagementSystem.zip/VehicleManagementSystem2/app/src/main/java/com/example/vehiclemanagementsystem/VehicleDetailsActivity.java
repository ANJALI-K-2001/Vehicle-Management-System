package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class VehicleDetailsActivity extends AppCompatActivity {
TextView modelname,vehicletype,milege,rentday,rcbook;
String modelnames,vehicletypes,mileges,rentdays,rcbooks,images;
Button pay;
ImageView imgs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicledetails);
        modelname=findViewById(R.id.mname);
        vehicletype=findViewById(R.id.vtp);
        milege=findViewById(R.id.mileage);
        rentday=findViewById(R.id.rentday);
        rcbook=findViewById(R.id.rcbook);
        pay=findViewById(R.id.pay);


        Intent intent=getIntent();
        modelnames=intent.getStringExtra("model_name");
        vehicletypes=intent.getStringExtra("vehicle_type");
        mileges=intent.getStringExtra("mileage");
        rcbooks=intent.getStringExtra("rc_book");
        images=intent.getStringExtra("images");

        modelname.setText(modelnames);
        vehicletype.setText(vehicletypes);
        milege.setText(mileges);
        rcbook.setText(rcbooks);
        rentday.setText(rentdays);




        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pay();
            }
        });

    }

    private void pay() {
startActivity(new Intent(getApplicationContext(),Payment.class));
    }
}