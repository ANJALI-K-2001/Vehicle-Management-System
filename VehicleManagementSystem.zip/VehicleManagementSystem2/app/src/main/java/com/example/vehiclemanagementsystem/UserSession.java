package com.example.vehiclemanagementsystem;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class UserSession {

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "User";

    public UserSession(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void createLoginSession(String id,String Username,String Password,String Email,String Phone,String Address,String Licenseno,String Fullname){
        editor.putString("id", id);
        editor.putString("Username", Username);
        editor.putString("Password", Password);
        editor.putString("Email", Email);
        editor.putString("Phone", Phone);
        editor.putString("Address", Address);
        editor.putString("Licenseno", Licenseno);
        editor.putString("Fullname", Fullname);
        editor.commit();
    }

    public HashMap<String, String> getUserDetails(){
        HashMap<String, String> user = new HashMap<>();
        user.put("id", pref.getString("id", null));
        user.put("Username", pref.getString("Username", null));
        user.put("Password", pref.getString("Password", null));
        user.put("Email", pref.getString("Email", null));
        user.put("Phone", pref.getString("Phone", null));
        user.put("Address", pref.getString("Address", null));
        user.put("Licenseno", pref.getString("Licenseno", null));
        user.put("Fullname", pref.getString("Fullname", null));
        return user;
    }

}
