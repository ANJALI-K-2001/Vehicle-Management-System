package com.example.vehiclemanagementsystem;

public class RequestModel {
    String id,status,user_id, username,fullname,phone_no;

    public RequestModel(String id,String status,String user_id, String username, String fullname,String phone_no) {
        this.id = id;
        this.status = status;
        this.user_id = user_id;
        this.username = username;
        this.fullname = fullname;
        this.phone_no = phone_no;


    }

    public String getid() {
        return id;
    }

    public String getstatus() {
        return status;
    }

    public String getUser_id() { return user_id; }

    public String getUsername() {
        return username;
    }

    public String getfullname() {
        return fullname;
    }

    public String getPhone_no() {
        return phone_no;
    }


}
