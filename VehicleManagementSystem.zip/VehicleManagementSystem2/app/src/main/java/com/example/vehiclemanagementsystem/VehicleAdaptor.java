package com.example.vehiclemanagementsystem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarException;

public class VehicleAdaptor extends RecyclerView.Adapter<VehicleAdaptor.MyViewHolder> {

    ArrayList<VehicleModel> data;
    Context c;
    LayoutInflater inflater;

    public VehicleAdaptor(Context c, ArrayList<VehicleModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_vehicle, parent, false);
        MyViewHolder holder = new MyViewHolder(v);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final VehicleModel model = data.get(position);

        holder.tvname.setText("Model Name: " + model.getModel_name());
        holder.tvyear.setText("Year: " + model.getYears());
        holder.tvregno.setText("Register Number: " + model.getReg_no());
        holder.tvvehtype.setText("Vehicle Type: " + model.getVehicle_type());
        if (!data.get(position).getImages().equals("")) {
            Picasso.get().load(Config.imgurl + data.get(position).getImages()).into(holder.imageView);
        }




//      holder.update.setOnClickListener(new View.OnClickListener() {
//           @Override
//        public void onClick(View view) {
//               Intent i = new Intent(c, AActivity.class);

//        if (!TextUtils.isEmpty(model.getImages())) {
//            Picasso.get()
//                    .load(model.getImages())
//                    .into(holder.img);
//        }

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(c, VehicleDetailsActivity.class);
                i.putExtra("username", model.getUsername());
                i.putExtra("model_name", model.getModel_name());
                i.putExtra("years", model.getYears());
                i.putExtra("reg_no", model.getReg_no());
                i.putExtra("insurance_expdate", model.getInsurance_expdate());
                i.putExtra("smoke_expdate", model.getSmoke_expdate());
                i.putExtra("License_expdate", model.getLicense_expdate());
                i.putExtra("vehicle_type", model.getVehicle_type());
                i.putExtra("rc_book", model.getRc_book());
                i.putExtra("insurance_certificate", model.getInsurance_certificate());
                i.putExtra("smoke_certificate", model.getSmoke_certificate());
                i.putExtra("License", model.getLicense());
                i.putExtra("images", model.getImages());
                c.startActivity(i);
            }
        });





        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteItem(model.getUsername(),model.getReg_no());
            }
        });

    }
    private void deleteItem(final String username, final String regno) {
        final String[] status = new String[1];
        final String[] message = new String[1];
        final String URL = Config.baseurl + "delete.php";


        StringRequest s = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Toast.makeText(c,response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");
                            message[0]=c.getString("message");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if ("1".equals(status[0])) {
                            Toast.makeText(c, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                            c.startActivity(new Intent(c, ListVehicleActivity.class));


                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("userid", username);
                params.put("reg_no", regno);


                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(c);
        queue.add(s);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvname,tvyear, tvregno, tvvehtype ;
        Button update,delete;
        CardView card;
        ImageView imageView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvname = itemView.findViewById(R.id.tvname);
            tvyear = itemView.findViewById(R.id.tvYear);
            tvregno = itemView.findViewById(R.id.tvregno);
            tvvehtype = itemView.findViewById(R.id.tvVehtype);

            update= itemView.findViewById(R.id.btvhupdate);
            delete= itemView.findViewById(R.id.btndelete);
            card = itemView.findViewById(R.id.card);
            imageView = itemView.findViewById(R.id.vimage);
        }
    }

}


