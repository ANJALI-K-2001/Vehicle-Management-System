package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MechanicLoginActivity extends AppCompatActivity {
    EditText etUsername, etPassword;
    Button btnMechlogin;
    Button btnmechregister;
    String status,message,url=Config.baseurl+"mech_login.php";
    String mechanic_id,username,password,fullname,phone_no,email,place,mechanic_type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_login);
        getSupportActionBar().hide();

        etUsername =findViewById(R.id.mechaniclogintxt);
        etPassword =findViewById(R.id.et_mechloginpassword);

        btnMechlogin=findViewById(R.id.mechlogin);
        btnmechregister=findViewById(R.id.btnMechreg);

        btnmechregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MechanicRegisterActivity.class);
                startActivity(i);

            }
        });


        btnMechlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setBtnmechlogin();
            }
        });



    }
    private void setBtnmechlogin() {
        final String Username = etUsername.getText().toString();
        final String Password = etPassword.getText().toString();




        if (TextUtils.isEmpty(Username)) {
            etUsername.setError("Please enter Username");
            etUsername.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Password)) {
            etPassword.setError("Please enter Password");
            etPassword.requestFocus();
            return;
        }

        Config.showSimpleProgressDialog(this);
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                Config.removeSimpleProgressDialog();

                        try {
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");
                            mechanic_id = data.getString("mechanic_id");
                            username = data.getString("username");
                            password = data.getString("password");
                            fullname= data.getString("fullname");
                            phone_no = data.getString("phone_no");
                            email = data.getString("email");
                            place = data.getString("place");
                            mechanic_type = data.getString("mechanic_type");
                            Toast.makeText(getApplicationContext(),mechanic_id+username+password+fullname+phone_no+email+place+mechanic_type, Toast.LENGTH_SHORT).show();




                            if (status.equals("1")) {
                                Toast.makeText(MechanicLoginActivity.this, message, Toast.LENGTH_SHORT).show();
                                new MechSession(MechanicLoginActivity.this).createLoginSession(mechanic_id,username,password,fullname,phone_no,email,place,mechanic_type);
                               Intent i =new Intent(getApplicationContext(), MechanicHomeActivitycardview.class);
                               startActivity(i);

                            }
                            else {
                                Toast.makeText(MechanicLoginActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(MechanicLoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Username", Username);
                params.put("Password", Password);





                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }
}
