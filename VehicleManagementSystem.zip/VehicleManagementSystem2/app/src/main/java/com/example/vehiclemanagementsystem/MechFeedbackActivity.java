package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MechFeedbackActivity extends AppCompatActivity {
    EditText etname, etmessage;
    Button proceed;
    String url = Config.baseurl + "user_feedback.php";
    String status, message;
    String name, feedmessage;
    String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mech_feedback);

        etname = findViewById(R.id.idname);
        etmessage = findViewById(R.id.idmessage);
        proceed = findViewById(R.id.btn);
        Intent i=getIntent();
        id=i.getStringExtra("id");
        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFeedbackFragment();
            }
        });


    }
    private void setFeedbackFragment () {
        name = etname.getText().toString();
        feedmessage = etmessage.getText().toString();


        if (TextUtils.isEmpty(name)) {
            etname.setError("Please enter name");
            etname.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(feedmessage)) {
            etmessage.setError("Please enter Message");
            etmessage.requestFocus();
            return;
        }

        Config.showSimpleProgressDialog(MechFeedbackActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Config.removeSimpleProgressDialog();

                        try {
                            //JSON Parsing
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(MechFeedbackActivity.this,"Feedback send Successfully" , Toast.LENGTH_SHORT).show();

                            } else {
                                Toast.makeText(MechFeedbackActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(MechFeedbackActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }

                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("mech_id", id);
                params.put("name", name);
                params.put("message", feedmessage);

                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(MechFeedbackActivity.this);
        queue.add(request);

    }

}

