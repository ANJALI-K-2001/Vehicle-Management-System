package com.example.vehiclemanagementsystem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mikhaellopez.circularimageview.CircularImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import mumayank.com.airlocationlibrary.AirLocation;

public class MechanicHomeActivitycardview extends AppCompatActivity {
    private static ProgressDialog mProgressDialog;
    TextView tvnamemech;
    CardView profilecvmech, requestscvmech, feedbackcvmech;
    CircularImageView profileimgmech;
    AirLocation airLocation;
    String latitude, longitude;
    String status, message, id;
    String url = Config.baseurl + "loc.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_cardview);
        getSupportActionBar().hide();

        fetchlocation();
        id = new UserSession(this).getUserDetails().get("id");

        tvnamemech = findViewById(R.id.tvnamemech);

        profilecvmech = findViewById(R.id.profile_cardviewmech);
        requestscvmech = findViewById(R.id.request_cardviewmech);

        feedbackcvmech = findViewById(R.id.feedback_cardviewmech);

        profileimgmech = findViewById(R.id.img);

        profilecvmech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(), MechanicProfileActivity.class);
                startActivity(i);
            }
        });

        requestscvmech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(), ViewRequestActivity.class);
                startActivity(i);
            }
        });
        feedbackcvmech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(), ViewFeedbackActivity.class);
                startActivity(i);
            }
        });


    }

    private void fetchlocation() {

        airLocation = new AirLocation(MechanicHomeActivitycardview.this, true, true, new AirLocation.Callbacks() {
            @Override
            public void onSuccess(Location location) {
                Toast.makeText(getApplicationContext(), "location fetched successfully", Toast.LENGTH_SHORT).show();
                double lat, lng;
                lat = location.getLatitude();
                lng = location.getLongitude();
                latitude = Double.toString(lat);
                longitude = Double.toString(lng);

                checkPermission();
            }

            @Override
            public void onFailed(AirLocation.LocationFailedEnum locationFailedEnum) {
                Toast.makeText(getApplicationContext(), "location fetching failed.please check your internet connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(MechanicHomeActivitycardview.this, new String[]{Manifest.permission.SEND_SMS}, 2);
        } else {
            uploadLocation();
        }
    }

    private void uploadLocation() {
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
               try {
                  Toast.makeText(MechanicHomeActivitycardview.this, response, Toast.LENGTH_SHORT).show();

                   JSONObject jsonobject = new JSONObject(response);
                    status = jsonobject.getString("status");
                    message = jsonobject.getString("message");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                /*if (status.equals("0")) {
                    Toast.makeText(homepage.this, message, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(homepage.this, message, Toast.LENGTH_SHORT).show();
                }*/

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("user_id", id);
                map.put("latitude", latitude);
                map.put("longitude", longitude);

                return map;
            }
        };
        RequestQueue requestqueue = Volley.newRequestQueue(this);
        requestqueue.add(request);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        airLocation.onActivityResult(requestCode, resultCode, data);
    }


    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }
            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }
        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}