package com.example.vehiclemanagementsystem;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RentAdapter extends RecyclerView.Adapter<RentAdapter.MyViewHolder> {

    ArrayList<RentModel> data;
    Context c;
    LayoutInflater inflater;

    public RentAdapter(Context c, ArrayList<RentModel> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_rent, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final RentModel model = data.get(position);

        holder.modelname.setText("Model Name: " + model.getModel_name());
//        holder.vehicletype.setText("Vehicle Type: " + model.getVehicle_type());
//        holder.mileage.setText("Mileage: " + model.getmileage());
        holder.tvrentday.setText("Rent Per Day: " + model.getRent_perday());
//        holder.tvrentmonth.setText("Rent Per Month: " + model.getRent_permonth());
        if (!data.get(position).getImages().equals("")) {
            Picasso.get().load(Config.imgurl + model.getImages()).into(holder.imageView);
        }
        Toast.makeText(c,model.getImages(), Toast.LENGTH_SHORT).show();

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(c, VehicleDetailsActivity.class);
                i.putExtra("username", model.getUsername());
                i.putExtra("model_name", model.getModel_name());
                i.putExtra("years", model.getYears());
                i.putExtra("reg_no", model.getReg_no());
                i.putExtra("km_drove", model.getKm_drove());
                i.putExtra("mileage", model.getmileage());
                i.putExtra("rent_perday", model.getRent_perday());
                i.putExtra("rent_permonth", model.getRent_permonth());
                i.putExtra("vehicle_type", model.getVehicle_type());
                i.putExtra("rc_book", model.getRc_book());
                i.putExtra("images", model.getImages());
                c.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView modelname,vehicletype,mileage,tvrentday,tvrentmonth;
ImageView imageView;
        CardView card;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            modelname = itemView.findViewById(R.id.modelname);
            tvrentday = itemView.findViewById(R.id.tvrentday);
            imageView = itemView.findViewById(R.id.img);
            card = itemView.findViewById(R.id.card);
        }
    }

}




