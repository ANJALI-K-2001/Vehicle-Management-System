package com.example.vehiclemanagementsystem;

public class VehicleModel {
    String vehicle_id, model_name, years, reg_no, insurance_expdate, smoke_expdate,License_expdate,vehicle_type, rc_book, insurance_certificate, smoke_certificate,License, images, username;

    public VehicleModel(String vehicle_id, String model_name, String years, String reg_no, String insurance_expdate, String smoke_expdate,String License_expdate, String vehicle_type, String rc_book, String insurance_certificate, String smoke_certificate, String License,String images, String username) {
        this.vehicle_id = vehicle_id;
        this.model_name = model_name;
        this.years = years;
        this.reg_no = reg_no;
        this.insurance_expdate = insurance_expdate;
        this.smoke_expdate = smoke_expdate;
        this.License_expdate = License_expdate;
        this.vehicle_type = vehicle_type;
        this.rc_book = rc_book;
        this.insurance_certificate = insurance_certificate;
        this.smoke_certificate = smoke_certificate;
        this.License = License;
        this.images = images;
        this.username = username;
    }

    public String getVehicle_id() {
        return vehicle_id;
    }

    public String getModel_name() {
        return model_name;
    }

    public String getYears() {
        return years;
    }

    public String getReg_no() {
        return reg_no;
    }

    public String getInsurance_expdate() {
        return insurance_expdate;
    }

    public String getSmoke_expdate() {
        return smoke_expdate;
    }

    public String getLicense_expdate() {
        return License_expdate;
    }

    public String getVehicle_type() {
        return vehicle_type;
    }

    public String getRc_book() {
        return rc_book;
    }

    public String getInsurance_certificate() {
        return insurance_certificate;
    }

    public String getSmoke_certificate() {
        return smoke_certificate;
    }

    public String getLicense() {
        return License;
    }

    public String getImages() {
        return images;
    }

    public String getUsername() {
        return username;
    }
}
