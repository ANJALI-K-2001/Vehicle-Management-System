package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MechanicEditProfileActivity extends AppCompatActivity {
    String Mechanic_id;
    EditText  etUsername,etmname, etPhone, etemail, etplace;
    Button btnupdate;
    String status, message, url = Config.baseurl + "mecp_update.php",Username,Fullname,Phone, Email, Place;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_editprofile);

        Mechanic_id = new MechSession(this).getMechDetails().get("mechanic_id");

        etUsername = findViewById(R.id.etUsername);
        etmname = findViewById(R.id.et_mname);
        etPhone= findViewById(R.id.etPhone);
        etemail = findViewById(R.id.et_email);
        etplace = findViewById(R.id.et_place);

        btnupdate = findViewById(R.id.btnupdate);
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setbtnupdate();
            }
        });
    }

    private void setbtnupdate() {

        Username = etUsername.getText().toString();
        Fullname = etmname.getText().toString();
        Phone= etPhone.getText().toString();
        Email = etemail.getText().toString();
        Place = etplace.getText().toString();


        if (TextUtils.isEmpty(Username)) {
            etUsername.setError("Please enter Username");
            etUsername.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Fullname)) {
            etmname.setError("Please enter Your Name");
            etmname.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(Phone)) {
            etPhone.setError("Please enter Phone Number");
            etPhone.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(Email)) {
            etemail.setError("Please enter Email id");
            etemail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(Place)) {
            etplace.setError("Please enter place");
            etplace.requestFocus();
            return;
        }

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Config.removeSimpleProgressDialog();

                        try {
                            Toast.makeText(MechanicEditProfileActivity.this, response, Toast.LENGTH_SHORT).show();
                            JSONObject data = new JSONObject(response);
                            status = data.getString("status");
                            message = data.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(MechanicEditProfileActivity.this, message, Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(MechanicEditProfileActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(MechanicEditProfileActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //add string parameters
                params.put("mechanic_id", Mechanic_id);
                params.put("username", Username);
                params.put("fullname", Fullname);
                params.put("phone_no", Phone);
                params.put("email", Email);
                params.put("place", Place);
                return params;
            }

        };
        RequestQueue rqueue = Volley.newRequestQueue(MechanicEditProfileActivity.this);
        rqueue.add(request);

    }
}