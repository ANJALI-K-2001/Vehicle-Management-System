package com.example.vehiclemanagementsystem;

public class MechanicModel {

    String id, username, password, Fullname, phone, email, place, mechanictype,distance;

    public MechanicModel(String id, String username, String password, String Fullname,
                         String phone, String email, String place, String mechanictype,String distance) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.Fullname = Fullname;
        this.phone = phone;
        this.email= email;
        this.place = place;
        this.mechanictype= mechanictype;
        this.distance = distance;


    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getFullname() {
        return Fullname;
    }

    public String getPlace() {
        return place;
    }

    public String getMechanictype() {
        return mechanictype;
    }

    public String getDistance() {
        return distance;
    }

}
