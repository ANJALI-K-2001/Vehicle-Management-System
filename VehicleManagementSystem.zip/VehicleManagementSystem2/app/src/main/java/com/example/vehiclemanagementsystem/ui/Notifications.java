package com.example.vehiclemanagementsystem.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.vehiclemanagementsystem.Config;
import com.example.vehiclemanagementsystem.Exp.Expadapter;
import com.example.vehiclemanagementsystem.Exp.Expdata;
import com.example.vehiclemanagementsystem.Exp.Explist;
import com.example.vehiclemanagementsystem.R;
import com.example.vehiclemanagementsystem.UserSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Notifications extends Fragment {
    String url = Config.baseurl + "doclist.php";
    ArrayList<Expdata> list;
    RecyclerView recycler;
    String userid;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_notifications, container, false);
        recycler = view.findViewById(R.id.recycler);

        HashMap<String,String> user= new UserSession(getActivity()).getUserDetails();
        userid=user.get("id");
        Toast.makeText(getActivity(), userid, Toast.LENGTH_SHORT).show();
        fetchData();
        return view;

    }

    private void fetchData() {
        list = new ArrayList<>();

        Config.showSimpleProgressDialog(getActivity() );

        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();

                        Config.removeSimpleProgressDialog();
                        try {
                            JSONArray data = new JSONArray(response);

                            for (int i = 0; i < data.length(); i++) {
                                JSONObject user = data.getJSONObject(i);


                                list.add(new Expdata(
                                        user.getString("vehicle_id"),
                                        user.getString("reg_no"),
                                        user.getString("insurance_expdate"),
                                        user.getString("smoke_expdate"),
                                        user.getString("License_expdate"),
                                        user.getString("vehicle_type"),
                                        user.getString("userid")


                                ));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        Expadapter adapter = new Expadapter(getActivity(), list);
                        recycler.setHasFixedSize(true);
                        recycler.setAdapter(adapter);
                        recycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Config.removeSimpleProgressDialog();
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String>map=new HashMap<>();
                map.put("userid",userid);
                return map;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(request);
    }
    }
