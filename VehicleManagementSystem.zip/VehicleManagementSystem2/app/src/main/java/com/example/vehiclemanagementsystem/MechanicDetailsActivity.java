package com.example.vehiclemanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MechanicDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_details);
    }
}