package com.example.vehiclemanagementsystem;

public class FeedbackModel {
    String name, message,mech_id;

    public FeedbackModel(String name, String message) {
        this.name = name;
        this.message = message;


    }
    public String getName() {
        return name;
    }

    public String getMessage() {
        return message;
    }

}
