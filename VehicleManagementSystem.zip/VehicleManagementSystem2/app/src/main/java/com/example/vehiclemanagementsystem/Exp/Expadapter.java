package com.example.vehiclemanagementsystem.Exp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vehiclemanagementsystem.FeedbackAdaptor;
import com.example.vehiclemanagementsystem.FeedbackModel;
import com.example.vehiclemanagementsystem.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Expadapter extends RecyclerView.Adapter<Expadapter.MyViewHolder> {
    ArrayList<Expdata> data;
    Context c;
    LayoutInflater inflater;

    public Expadapter(Context c, ArrayList<Expdata> data) {
        this.data = data;
        this.c = c;
        inflater = LayoutInflater.from(c);
    }
    @NonNull
    @Override
    public Expadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_exp, parent, false);
        Expadapter.MyViewHolder holder = new Expadapter.MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Expadapter.MyViewHolder holder, int position) {
        final Expdata model = data.get(position);


       //holder.i.setText("Insur : " + model.getInsurance_expdate());
//        holder.s.setText("Smoke : " + model.getSmoke_expdate());
        holder.reg.setText(model.getReg_no());

        String date = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        Toast.makeText(c, date, Toast.LENGTH_SHORT).show();

        if(date.equals(model.getInsurance_expdate())){
            holder.i.setText("Insurance expired"   +"\n"+ model.getInsurance_expdate());

        }
        if(date.equals(model.getSmoke_expdate())){
            holder.s.setText("Smoke certificate expired"   +"\n"+ model.getSmoke_expdate());
        }
        if(date.equals(model.getLicense_expdate())){
            holder.l.setText("Vehicle License expired"   +"\n"+ model.getLicense_expdate());
        }
    }



    @Override
    public int getItemCount() {
        return data.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView i,s,l,reg;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            i=itemView.findViewById(R.id.insurance_expdate);
            s=itemView.findViewById(R.id.smoke_expdate);
            l=itemView.findViewById(R.id.license_expdate);
            reg=itemView.findViewById(R.id.regno);

        }
    }
}
